var map;
var epsg4326 ;
var epsg900913;
var epsg2154;
var style_green;
var vectorLayerJSON ;
      
    OpenLayers.ProxyHost = "/cgi-bin/proxy.cgi?url=";
    
    
function init() {
 



  var options = {
		controls: [],
		  hover: false,
         // Fait reference a la fonction popUp
        //onSelect: popUP,
		projection: epsg900913,
		displayProjection: epsg4326,
		units : "m",
		extent: [-5, 35, 15, 55],
		maxResolution: 156543.0339,
		maxExtent: new OpenLayers.Bounds(-20037508, -20037508, 20037508, 20037508.34)
	};

 var vectorLayer = new OpenLayers.Layer.Vector("vector");
 
 epsg4326 = new OpenLayers.Projection('EPSG:4326');
 epsg900913 = new OpenLayers.Projection('EPSG:900913');

  var style = new OpenLayers.StyleMap({ 
    'default': {
        externalGraphic:'imae.jpg',
        graphicHeight: 32,
        graphicWidth: 32,
        graphicXOffset: -16,
        graphicYOffset: -32,
        fillOpacity: 0.75
    }
  });


 style_green = {
                strokeColor: "#00FF00",
                strokeWidth: 3,
                pointRadius: 6,
                pointerEvents: "visiblePainted"
            };

  map = new OpenLayers.Map('', options);

  var osmLayer = new OpenLayers.Layer.OSM();
    var gmap = new OpenLayers.Layer.Google("Google Streets", {visibility: false});
	var gsat = new OpenLayers.Layer.Google(
	"Google Satellite",
	{type: google.maps.MapTypeId.SATELLITE, numZoomLevels: 22,
	sphericalMercator: true}
	);

  var opinionswms = new OpenLayers.Layer.WMS(
  "Toutes Opinions",
  "http://localhost:8080/geoserver/tiger/wms",
  {
  projection: epsg900913,
  layers: "tiger:ToutesOpinions",
  transparent: true,
  style: "style_green",
  format: 'image/png'
  },
  {
  singleTile: false,
  opacity: 1,
  isBaseLayer : false
});
  
    var opinionsnegatif = new OpenLayers.Layer.WMS(
  "Opinions Négatifs",
  "http://localhost:8080/geoserver/tiger/wms",
  {
  projection: epsg900913,
  layers: "tiger:OpinionsNegatifs",
  transparent: true,
  format: 'image/png'
  },
  {
  singleTile: false,
  opacity: 1,
  isBaseLayer : false
});
    
     var opinionspostifs = new OpenLayers.Layer.WMS(
  "Opinions Positifs",
  "http://localhost:8080/geoserver/tiger/wms",
  {
  projection: epsg900913,
  layers: "tiger:Opinions-Positifs",
  transparent: true,
  format: 'image/png'
  },
  {
  singleTile: false,
  opacity: 1,
  isBaseLayer : false
});
    
     
  var sousquartiers = new OpenLayers.Layer.WMS(
  "sousquartiers",
  "http://localhost:8080/geoserver/tiger/wms",
  {
  projection: epsg900913,
  layers: "tiger:sousquartiers1",
  transparent: true,
  format: 'image/png'
  },
  {
  singleTile: false,
  opacity: 1,
  isBaseLayer : false
});
    

    map.addLayers([osmLayer, gmap, gsat, opinionswms,opinionsnegatif,opinionspostifs,sousquartiers]);
    

     var info = new OpenLayers.Control.WMSGetFeatureInfo({
            url: 'http://localhost:8080/geoserver/tiger/wms',
	    layers: [opinionspostifs,opinionsnegatif,opinionswms],
            title: 'Informations',
            queryVisible: true,
            eventListeners: {
                getfeatureinfo: function(e) {
                   new GeoExt.Popup({
                title: "Feature Info",
                 autoWidth: true,
		 autoHeight: true,
               
		html:e.text,
               
                map: map,
                location: e.xy,
                
            }).show();
                }
            }
        });
        map.addControl(info);
        info.activate();
	
map.addControl(new OpenLayers.Control.MousePosition({displayProjection: epsg4326})); //affichage localisation de la souris
var mapBounds = new OpenLayers.Bounds(3.46,43.42,3.74,43.34).transform(epsg4326,epsg900913);
//vectorLayer.addFeatures([pointFeature, pointFeature2]);


    map.zoomToMaxExtent();

map.addControl(new OpenLayers.Control.Navigation());
map.addControl(new OpenLayers.Control.PanZoomBar({zoomWorldIcon: true}));
map.addControl(new OpenLayers.Control.OverviewMap({autoPan : true}));
map.addControl(new OpenLayers.Control.KeyboardDefaults()); //se déplacer avec le clavier
map.addControl(new OpenLayers.Control.ScaleLine()); //barre d'échelle
map.addControl(new OpenLayers.Control.LayerSwitcher());


//************************* Sélection zoom*******************


var scaleStore = new GeoExt.data.ScaleStore({map: map});


var zoomSelector = new Ext.form.ComboBox({
        store: scaleStore,
        emptyText: "Zoom Level",
        tpl: '<tpl for="."><div class="x-combo-list-item">1 : {[parseInt(values.scale)]}</div></tpl>',
        editable: false,
        triggerAction: 'all', // needed so that the combo box doesn't filter by its current content
        mode: 'local' // keep the combo box from forcing a lot of unneeded data refreshes
    });

    zoomSelector.on('select', 
        function(combo, record, index) {
            map.zoomTo(record.data.level);
        },
        this
    );     

    map.events.register('zoomend', this, function() {
        var scale = scaleStore.queryBy(function(record){
            return this.map.getZoom() == record.data.level;
        });

        if (scale.length > 0) {
            scale = scale.items[0];
            zoomSelector.setValue("1 : " + parseInt(scale.data.scale));
        } else {
            if (!zoomSelector.rendered) return;
            zoomSelector.clearValue();
        }
    });
    
//***************************************************************
    

    var mapPanel = new GeoExt.MapPanel({
map: map,
region : 'center',
height: '800',
width: '600',
title: 'Opinions',
collapsible: false,
border: true,
extent: mapBounds,
//plugins: new GeoExt.ZoomSliderTip()
bbar: [zoomSelector]
});
    


var treeConfig = new OpenLayers.Format.JSON().write([
        {
            nodeType    : 'gx_baselayercontainer',
            text        : 'Fonds de cartes'
            ,expanded   : false
            ,allowDrag  : false
            ,allowDrop  : false
            ,draggable  : false
        }, {
           text        : 'Points'
            ,allowDrag  : true
            ,allowDrop  : true
            ,draggable  : true
            ,icon       : 'image.jpg'
            ,expanded   : false
            ,children   : [
                
		{
                    nodeType    : 'gx_layer'
                    ,draggable  : true
                    ,layer      : 'Toutes Opinions'
                    ,qtip       : "Toutes Opinions"
            	    ,icon       : 'pointnoir.png'
                },
		{
                    nodeType    : 'gx_layer'
                    ,draggable  : true
                    ,layer      : 'Opinions Positifs'
                    ,qtip       : "Opinions Positifs"
            	    ,icon       : 'pointvert.png'
                },
		{
                    nodeType    : 'gx_layer'
                    ,draggable  : true
                    ,layer      : 'Opinions Négatifs'
                    ,qtip       : "Opinions Négatifs"
            	    ,icon       : 'pointrouge.png'
                }                   
            ]
        }
], true);

    var layerTree = new Ext.tree.TreePanel({
        title       : "Layers"
        ,root: {
            nodeType    : "async"
            ,expanded   : true
            ,children   : Ext.decode(treeConfig)
        }
        ,loader: new Ext.tree.TreeLoader({
            applyLoader: false
        })
        ,animate    : true
        ,enableDD   : true
        ,useArrows  : true        
        ,rootVisible: false
    });

 var accordion = new Ext.Panel({
        margins : '5 0 5 5'
        ,split  : true
        ,width  : 160
        ,layout :'accordion'
        ,items  : [layerTree]
    });  
 
	var eastPanel = new Ext.Panel({  
	title   : 'Légende et données'      
        ,region : 'east'
        , collapsible : 'true'
        ,layout : 'fit'
        ,width  : 220   
        ,items  : [accordion]
    });
	


new Ext.Viewport({
layout: "border",
defaults: {
split: true
},
items: [
mapPanel,
eastPanel
]
});
}


  